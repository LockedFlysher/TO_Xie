# # Introduction
# coding=utf-8
import sys
import numpy as np
import pybullet as p
import math
import time
import pybullet_data
import controlpy
import pos_ang
import lcm
import exlcm import lcmpy

global pos_pos
pos_pos = 0
global odom
# 位置暂存
global pos_pitch
pos_pitch = 0
# 俯仰角的暂存，用于计算俯仰角速度
global pos_yaw
pos_yaw = 0
# 偏航角的暂存，用于计算偏航速度

# 状态空间是必要的
# 公式推导后略
# 参数表
# (mw)              mass of the cart                         kg
# (mb)              mass of the pendulum                     kg
# (b)               coefficient of friction for cart         N/m/sec
# (l)               length to pendulum center of mass        m
# (r)               Radius of wheel
# (d)               Distance between wheels
# (I1,I2,I3)        mass moment of inertia of the pendulum   kg.m^2
# (K,J)             MOI of wheel
# (F)               force applied to the cart
# (x)               cart position coordinate
# (theta)           pendulum angle from vertical (down)

# x(t+1)=A*x(t)+B*u
# x(t+1)=k*x(t)

mw = 0.028
mb = 0.234
l  = 0.02922
r  = 0.03
d  = 0.09
I1 = 0.000145729
I2 = 0.000143515
I3 = 0.000143690
K  = 0.000006597
J  = 0.000012723
g  = 9.8
u1 = (mb+2*mw+(2*J)/(r**2))*(I2+mb*(l**2))-(mb**2)*(l**2)
u2 = I3+2*K+2*(mw+J/(r**2))*(d**2)
a2 = -(mb**2)*g*(l**2)/u1
a4 = (mb+2*mw+2*J/(r**2))*mb*g*l/u1
b2 = ((I2+mb*(l**2))/r+mb*l)/u1
b4 = -((mb*l)/r+mb+2*mw+2*J/(r**2))/u1
b6 = -(d/r)/u2

####################### write your code here #####################################################################################
# Refer to "test_lqr.py" for example code
# Variable : "A" : 2D numpy array
# Variable : "A" : 2D numpy array
# write here
A = np.array([[0,1,0,0,0,0],
              [0,0,a2,0,0,0],
              [0,0,0,1,0,0],
              [0,0,a4,0,0,0],
              [0,0,0,0,0,1],
              [0,0,0,0,0,0]])
B = np.array([[0,0],[b2,b2],[0,0],[b4,b4],[0,0],[b6,-b6]])

class SelfBalanceLQR:
    '''
    Purpose:
    ---
    Class Describing the gains of LQR and various functions
    Functions:
    ---
        __init__ : Called by default to initilize the variables in LQR
        callback : It takes the data from sensors/bots and accordingly predicts the next state and respecive action
        callback_q : It can be used to change the value of gains during execution
        callback_r : It can be used to change the value of gains during execution
    Example initialization and function call:
    ---
    balance=SelfBalanceLQR()
    vel=balance.callback(data)
    '''
    def __init__(self):
        # 以下几个参数存储的是前一刻的状态
        self.yaw_ = 0
        self.pitch_ = 0
        self.odom_ = 0
        # 设置QR矩阵
        self.Q = np.array([[1,0,0,0,0,0],
                           [0,10,0,0,0,0],
                           [0,0,100,0,0,0],
                           [0,0,0,10,0,0],
                           [0,0,0,0,100,0],
                           [0,0,0,0,0,1]])
        R_set = 2500
        self.R = [[R_set,0],
                  [0,R_set]]
        self.K, self.S, self.e = controlpy.synthesis.controller_lqr(A, B, self.Q, self.R)
        print(self.K)

    def callback(self, data):
        np_x = data
        y = p.getBasePositionAndOrientation(robot)[1][2]
        u_t=-np.matmul(self.K, np_x)
        # print(np_x,self.K,u_t)
        # print(np_x.shape,self.K.shape,u_t.shape,A.shape,B.shape)
        xvel = (np.matmul(A, np_x)+np.matmul(B, u_t))[1]
        linear_vel = [xvel, 0, 0]
        angular_vel = [0, 0, 0]
        self.yaw_ = y
        #self.odom_=data[]
        return u_t

def synthesizeData (robot):
    '''
    Purpose:
    ---
    Calculate the current state(position , velocity , orienation etc.)
    Input Arguments:
    ---
    `robot` :  integer
        object id of bot spawned in pybullet
    Returns:
    ---
    `data` :  1D array
        list of information required for calculation
    Example call:
    ---
    data=synthesizeData(robot)
    '''
    data = np.zeros([6, 1])
    # print(data[2][0])
    # data[0][0] = p.getBasePositionAndOrientation(robot)[0][0]
    #a = p.getEulerFromQuaternion(p.getLinkState(robot, 0, computeLinkVelocity=1)[5])[1]
    a = p.getBaseVelocity(robot)[0][0]
    data[1][0] = a
    data[0][0] = 0
    global pos_pitch
    data[2][0] = (p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot)[1])[1])
    # 存入全局变量提供给下一个计算使用
    vel_pitch = -(pos_pitch - data[2][0]) * 240
    data[3][0] = vel_pitch
    pos_pitch = data[2][0]
    global pos_yaw
    data[4][0] = p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot)[1])[2]
    #print("偏航角yaw:",pos_yaw,"俯仰角:",pos_pitch)
    vel_yaw = -(pos_yaw - data[4][0])*240
    pos_yaw = data[4][0]
    data[5][0] = vel_yaw

    #############################################################################################################################
    return data


if __name__ == "__main__":
    '''
    Purpose:
    ---
        Setup the pybullet environment and calculation of state variables and respective action to balance the bot
    '''
    id = p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    plane = p.loadURDF("/home/sean/.local/lib/python3.8/site-packages/pybullet_data/plane.urdf")
    robot = p.loadURDF("/home/sean/NeZha-mpc/bipedal/urdf/bipedal.urdf" , [0,0,0.3])
    left_joint = 0
    right_joint = 1
    maxForce = 0
    mode = p.VELOCITY_CONTROL
    p.setJointMotorControl2(robot, left_joint, controlMode=mode, force=maxForce)
    p.setJointMotorControl2(robot, right_joint, controlMode=mode, force=maxForce)


    p.changeDynamics(robot,left_joint,lateralFriction=1,spinningFriction=1,rollingFriction=0.01)
    p.changeDynamics(robot,right_joint,lateralFriction=1,spinningFriction=1,rollingFriction=0.01)
    balance = SelfBalanceLQR()


    while (True) :
        data = synthesizeData(robot)#get data from simulation and bot

        keys = p.getKeyboardEvents()
        if ord("r") in keys and keys[ord("r")] & p.KEY_IS_DOWN:
            data[1] = data[2] + 1
        if ord("f") in keys and keys[ord("f")] & p.KEY_IS_DOWN:
            data[1] = data[2] - 1
        if ord("d") in keys and keys[ord("d")] & p.KEY_IS_DOWN:
            data[4] = data[4] + 1
        if ord("g") in keys and keys[ord("g")] & p.KEY_IS_DOWN:
            data[4] = data[4] - 1

        trq = #call to function to implement algorithm
        # 设置机器关节的转矩大小,转矩是电机的一般控制量，选择为仿真的输入量
        max = 2
        min = 0.05
        if abs(trq[0]) < min:
            trq[0] = 0
        if abs(trq[0]) > max:
            if trq[0] > 0:
                trq[0]=max
            if trq[0] < 0:
                trq[0] = -max
        if abs(trq[1]) < min:
            trq[1] = 0
        if abs(trq[1]) > max:
            if trq[1] > 0:
                trq[1]=max
            if trq[1] < 0:
                trq[1] = -max
        #print(trq)
        p.setJointMotorControl2(robot, left_joint, p.TORQUE_CONTROL, force=trq[0])
        p.setJointMotorControl2(robot, right_joint, p.TORQUE_CONTROL, force=trq[1])
        p.stepSimulation()
        # 拿到物体坐标，设置相机坐标
        location, _ = p.getBasePositionAndOrientation(robot)
        p.resetDebugVisualizerCamera(
            cameraDistance=0.2,
            cameraYaw=110,
            cameraPitch=-30,
            cameraTargetPosition=location
        )
        time.sleep(1/1000)

