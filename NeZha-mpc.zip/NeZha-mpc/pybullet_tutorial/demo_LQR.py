# Description the implementation of Control Systems namely [LQR](#lqr_sec) on our robot.
import sys
from pynput import keyboard
import numpy as np
import pybullet as p
import math
import time
import pybullet_data
import controlpy
import pos_ang

global pos_pitch # 记录上一时刻的俯仰角
global pos_pos
pos_pitch = 0
pos_pos = 0

# 状态空间是必要的
# 公式推导后略
# 参数表
# (M)       mass of the cart                         kg
# (m)       mass of the pendulum                     kg
# (b)       coefficient of friction for cart         N/m/sec
# (l)       length to pendulum center of mass        m
# (I)       mass moment of inertia of the pendulum   kg.m^2
# (F)       force applied to the cart
# (x)       cart position coordinate
# (theta)   pendulum angle from vertical (down)

# x(t+1)=A*x(t)+B*u
# x(t+1)=k*x(t)

M = 0.061;
m = 0.425;
b = 1;
I = 0.0060700391309238813;
g = 9.8;
l = 0.191333;

A = (np.array([[0,1,0,0],[0,0,-(m*g)/M,0],[0,0,0,1],[0,0,((m+M)*g)/(M*l),0]]))
B = np.array([[0],[1/M],[0],[-1/(M*l)]])

############################################################################################# 吧######################################

# The class for LQR

# Q = np.array([[ 100,   0],[  0, 1000]])
# R = 0.0001
# K,S,e = lqr(A,B,Q,R)
# print(K)
# print(S)
# print(e)
# 让损失函数得到最小值
# LQR控制类

def on_press(key):
    '按下按键时执行。'
    try:
        if key == keyboard.KeyCode.from_char('w'):
            print("forward")
        #     return 5
        # else:
        #     return 0

    except AttributeError:
        print('special key {0} pressed'.format(key))


class SelfBalanceLQR:
    '''
    Purpose:
    ---
    Class Describing the gains of LQR and various functions
    Functions:
    ---
        __init__ : Called by default to initilize the variables in LQR
        callback : It takes the data from sensors/bots and accordingly predicts the next state and respecive action
        callback_q : It can be used to change the value of gains during execution
        callback_r : It can be used to change the value of gains during execution
    Example initialization and function call:
    ---
    balance=SelfBalanceLQR()
    vel=balance.callback(data)
    '''
    def __init__(self):
        self.xvelMin=-.01# x velocity
        self.xvelMax =0
        self.yMin = -0.01#yaw
        self.yMax = 0
        self.y_ = 0
        # 设置QR矩阵
        self.Q = np.array([[0.1, 0 ,0 ,0],[0,0.0001,0,0],[0,0,10,0],[0,0,0,0.1]])
        self.R = [[100]]
        self.K,self.S,self.e = controlpy.synthesis.controller_lqr(A,B,self.Q,self.R)

    def callback(self, data):
        ######################################## write yor code here ######################################################
        # 从机器人的数据来进行计算一些参数
        # Variable np_x : 2D array of state to be multiplie with A
        # Variable y : integer representing the state value that is used to calculate error/other states
        #write here
        np_x = data
        y = p.getBasePositionAndOrientation(robot)[1][2]
        u_t=-np.matmul(self.K, np_x)
        #print(np_x,self.K,u_t)
        #print(np_x.shape,self.K.shape,u_t.shape,A.shape,B.shape)
        xvel = (np.matmul(A, np_x)+np.matmul(B, u_t))[1] ##### might have to change this based on your state equation
        self.y_ = y
        return u_t


def synthesizeData (robot):
    data = np.zeros([4,1])
    data[2][0] = (p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot)[1])[1])
    #print(data[2][0])
    odom = pos_ang.odom(p.getBasePositionAndOrientation(robot)[0][:2])

    global pos_pos
    data[0][0] = odom
    data[1][0] = (pos_pos-odom)*240
    pos_pos = odom
    global pos_pitch
    vel_pitch = -(pos_pitch - (p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot)[1])[1]))*240
    pos_pitch = p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot)[1])[1]
    data[3][0] = vel_pitch
    ##########################################################################################################
    return data


if __name__ == "__main__":
    '''
    Purpose:
    --
        Setup the pybullet environment and calculation of state variables and respective action to balance the bot
    '''
    # connecting to pybullet
    id = p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    plane = p.loadURDF("/home/lock/.local/lib/python3.8/site-packages/pybullet_data/plane.urdf")
    p.setGravity(0, 0, -9.8)

    robot = p.loadURDF("/home/lock/桌面/dachuang/urdf/wide.SLDASM/urdf/wide.SLDASM.urdf" , [0,0,0.45])
    left_joint=0
    right_joint=1
    maxForce = 0
    mode = p.VELOCITY_CONTROL
    p.setJointMotorControl2(robot, left_joint,controlMode=mode, force=maxForce)
    #p.setJointMotorControl2(robot, right_joint,controlMode=mode, force=maxForce)
    p.changeDynamics(robot,left_joint,lateralFriction=1,spinningFriction=1,rollingFriction=0.001)
    #p.changeDynamics(robot,right_joint,lateralFriction=0.7,spinningFriction=0.5,rollingFriction=0.5)
    balance = SelfBalanceLQR()

    while(True):
        data = synthesizeData(robot)#get data from simulation and bot


        keys = p.getKeyboardEvents()
        if ord("r") in keys and keys[ord("r")] & p.KEY_IS_DOWN:
            data[2] = data[2] + 0.1
        if ord("f") in keys and keys[ord("f")] & p.KEY_IS_DOWN:
            data[2] = data[2] - 0.1


        trq = balance.callback(data)#call to function to implement algorithm
        if trq > 1:
            trq = 1
        if trq < -1:
            trq = -1
        #print(trq)
        # 设置机器关节的转矩大小,转矩是电机的一般控制量，选择为仿真的输入量
        p.setJointMotorControl2(robot, left_joint, p.TORQUE_CONTROL, force = -trq)
        #p.setJointMotorControl2(robot, right_joint , p.TORQUE_CONTROL, force = -4*trq)
        p.stepSimulation()
        # 拿到物体坐标，设置相机坐标
        location, _ = p.getBasePositionAndOrientation(robot)
        p.resetDebugVisualizerCamera(
            cameraDistance=0.5,
            cameraYaw=110,
            cameraPitch=-30,
            cameraTargetPosition=location
        )
        time.sleep(1/240)
