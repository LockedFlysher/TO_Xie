import math

def transform_from_quanternion_to_eula_angle(quanternions):
    w = float(quanternions[3])
    x = float(quanternions[0])
    y = float(quanternions[1])
    z = float(quanternions[2])

    r = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    p = math.asin(2 * (w * y - z * x))
    y = math.atan2(2 * (w * z + x * y), 1 - 2 * (z * z + y * y))

    angleR = r * 180 / math.pi
    angleP = p * 180 / math.pi
    angleY = y * 180 / math.pi

    return [angleR, angleP, angleY]

def get_accelaration (accelerator,present_pos,step_time):
    accelerator[0] = accelerator[1]
    accelerator[1] = accelerator[2]
    accelerator[2] = present_pos
    a = ((accelerator[2]-accelerator[1])/step_time-(accelerator[1]-accelerator[0])/step_time)/step_time
    return a

def abs_velocity (velocity):
    s = math.sqrt(velocity[0]*velocity[0] + velocity[1]*velocity[1] + velocity[2]*velocity[2])
    return s

def getEulerVelocity():
    pass