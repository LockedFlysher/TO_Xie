/**
 * @file MPCExample.cpp
 * @author Giulio Romualdi
 * @copyright Released under the terms of the BSD 3-Clause License
 * @date 2018
 */

// osqp-eigen
#include "OsqpEigen/OsqpEigen.h"
// lcm
#include <lcm/lcm-cpp.hpp>
#include "src/lcmh/exlcm/lcmcpp.hpp"
// eigen
#include <Eigen/Dense>
#include <iostream>
// 定义了一个设置参数的函数a(6x6) b(6*2)
void setDynamicsMatrices(Eigen::Matrix<double, 6, 6> &a, Eigen::Matrix<double, 6, 2> &b)
{
    double mw = 0.028;
    double mb = 0.234;
    double l = 0.02922;
    double r = 0.03;
    double d = 0.09;
    double I1 = 0.000145729;
    double I2 = 0.000143515;
    double I3 = 0.000143690;
    double K = 0.000006597;
    double J = 0.000012723;
    double g = 9.8;
    double t = 0.5;
    double u1 = (mb + 2 * mw + (2 * J) / pow(r, 2)) * (I2 + mb * pow(l, 2)) - pow(mb, 2) * pow(l, 2);
    double u2 = I3 + 2 * K + 2 * (mw + J / pow(r, 2)) * pow(d, 2);
    double a2 = -pow(mb, 2) * g * pow(l, 2) / u1;
    double a4 = (mb + 2 * mw + 2 * J / pow(r, 2)) * mb * g * l / u1;
    double b2 = ((I2 + mb * pow(l, 2)) / r + mb * l) / u1;
    double b4 = -((mb * l) / r + mb + 2 * mw + 2 * J / pow(r, 2)) / u1;
    double b6 = -(d / r) / u2;
    a.resize(6,6);
    b.resize(6,2);
    a << 0., 1., 0., 0., 0., 0.,
        0., 0., a2, 0., 0., 0.,
        0., 0., 0., 1., 0., 0.,
        0., 0., a4, 0., 0., 0.,
        0., 0., 0., 0., 0., 1.,
        0., 0., 0., 0., 0., 0.;
    // 将连续的系统转化为离散的系统
    a = Eigen::MatrixXd::Identity(6,6)+a*t;
    b << 0., 0.,
        b2, b2,
        0., 0.,
        b4, b4,
        0., 0.,
        b6, -b6;
    // b矩阵做同样的操作
    b = b*t;
}

// 设置上下限
void setInequalityConstraints(Eigen::Matrix<double, 6, 1> &xMax, Eigen::Matrix<double, 6, 1> &xMin,
                              Eigen::Matrix<double, 2, 1> &uMax, Eigen::Matrix<double, 2, 1> &uMin)
{
    // 根据物理模型的矩阵来进行初始化上下限
    // input inequality constraints
    uMin << -10,-10;

    uMax << 10,10;

    // state inequality constraints
    xMin << -10,-10,-10,-10,-10,-10;
    xMax << 10,10,10,10,10,10;
}

// 设置权重矩阵
void setWeightMatrices(Eigen::DiagonalMatrix<double, 6> &Q, Eigen::DiagonalMatrix<double, 2> &R)
{
    Q.diagonal() << 1, 10., 1., 10., 1., 10.;
    R.diagonal() << 0.1, 0.1;
}

// 将MPC问题转换成QP问题
// Hessian Matrix（海森矩阵）
// Hessian Matrix，译作黑塞矩阵、海森矩阵、海瑟矩阵、海塞矩阵等。是一个多元函数的二阶偏导数构成的方阵，描述了函数的局部曲率。Hessian Matrix最早于19世纪由德国数学家Ludwig Otto Hesse提出，并以其名字命名。
// Hessian Matrix常用于牛顿法解决优化问题，利用Hessian Matrix可判定多元函数的极值问题。
// 在工程实际问题的优化设计中，所列的目标函数往往很复杂，为了使问题简化，常常将目标函数在某点邻域展开成泰勒多项式来逼近原函数，此时函数在某点泰勒展开式的矩阵形式中会涉及到Hessian Matrix。
void castMPCToQPHessian(const Eigen::DiagonalMatrix<double, 6> &Q, const Eigen::DiagonalMatrix<double, 2> &R, int mpcWindow,
                        Eigen::SparseMatrix<double> &hessianMatrix)
{

    hessianMatrix.resize(6 * (mpcWindow + 1) + 2 * mpcWindow, 6 * (mpcWindow + 1) + 2 * mpcWindow);

    // populate hessian matrix
    for (int i = 0; i < 6 * (mpcWindow + 1) + 2 * mpcWindow; i++)
    {
        if (i < 6 * (mpcWindow + 1))
        {
            int posQ = i % 6;
            float value = Q.diagonal()[posQ];
            if (value != 0)
                hessianMatrix.insert(i, i) = value;
        }
        else
        {
            int posR = i % 2;
            float value = R.diagonal()[posR];
            if (value != 0)
                hessianMatrix.insert(i, i) = value;
        }
    }
}

void castMPCToQPGradient(const Eigen::DiagonalMatrix<double, 6> &Q, const Eigen::Matrix<double, 6, 1> &xRef, int mpcWindow,
                         Eigen::VectorXd &gradient)
{

    Eigen::Matrix<double, 6, 1> Qx_ref;
    Qx_ref = Q * (-xRef);

    // populate the gradient vector
    gradient = Eigen::VectorXd::Zero(6 * (mpcWindow + 1) + 2 * mpcWindow, 1);
    for (int i = 0; i < 6 * (mpcWindow + 1); i++)
    {
        int posQ = i % 6;
        float value = Qx_ref(posQ, 0);
        gradient(i, 0) = value;
    }
}

void castMPCToQPConstraintMatrix(const Eigen::Matrix<double, 6, 6> &dynamicMatrix, const Eigen::Matrix<double, 6, 2> &controlMatrix,
                                 int mpcWindow, Eigen::SparseMatrix<double> &constraintMatrix)
{
    constraintMatrix.resize(6 * (mpcWindow + 1) + 6 * (mpcWindow + 1) + 2 * mpcWindow, 6 * (mpcWindow + 1) + 2 * mpcWindow);

    // populate linear constraint matrix
    for (int i = 0; i < 6 * (mpcWindow + 1); i++)
    {
        constraintMatrix.insert(i, i) = -1;
    }

    for (int i = 0; i < mpcWindow; i++)
        for (int j = 0; j < 6; j++)
            for (int k = 0; k < 6; k++)
            {
                float value = dynamicMatrix(j, k);
                if (value != 0)
                {
                    constraintMatrix.insert(6 * (i + 1) + j, 6 * i + k) = value;
                }
            }

    for (int i = 0; i < mpcWindow; i++)
        for (int j = 0; j < 6; j++)
            for (int k = 0; k < 2; k++)
            {
                float value = controlMatrix(j, k);
                if (value != 0)
                {
                    constraintMatrix.insert(6 * (i + 1) + j, 2 * i + k + 6 * (mpcWindow + 1)) = value;
                }
            }

    for (int i = 0; i < 6 * (mpcWindow + 1) + 2 * mpcWindow; i++)
    {
        constraintMatrix.insert(i + (mpcWindow + 1) * 6, i) = 1;
    }
}

void castMPCToQPConstraintVectors(const Eigen::Matrix<double, 6, 1> &xMax, const Eigen::Matrix<double, 6, 1> &xMin,
                                  const Eigen::Matrix<double, 2, 1> &uMax, const Eigen::Matrix<double, 2, 1> &uMin,
                                  const Eigen::Matrix<double, 6, 1> &x0,
                                  int mpcWindow, Eigen::VectorXd &lowerBound, Eigen::VectorXd &upperBound)
{
    // evaluate the lower and the upper inequality vectors
    Eigen::VectorXd lowerInequality = Eigen::MatrixXd::Zero(6 * (mpcWindow + 1) + 2 * mpcWindow, 1);
    Eigen::VectorXd upperInequality = Eigen::MatrixXd::Zero(6 * (mpcWindow + 1) + 2 * mpcWindow, 1);
    for (int i = 0; i < mpcWindow + 1; i++)
    {
        lowerInequality.block(6 * i, 0, 6, 1) = xMin;
        upperInequality.block(6 * i, 0, 6, 1) = xMax;
    }
    for (int i = 0; i < mpcWindow; i++)
    {
        lowerInequality.block(2 * i + 6 * (mpcWindow + 1), 0, 2, 1) = uMin;
        upperInequality.block(2 * i + 6 * (mpcWindow + 1), 0, 2, 1) = uMax;
    }

    // evaluate the lower and the upper equality vectors
    Eigen::VectorXd lowerEquality = Eigen::MatrixXd::Zero(6 * (mpcWindow + 1), 1);
    Eigen::VectorXd upperEquality;
    lowerEquality.block(0, 0, 6, 1) = -x0;
    upperEquality = lowerEquality;
    lowerEquality = lowerEquality;

    // merge inequality and equality vectors
    lowerBound = Eigen::MatrixXd::Zero(2 * 6 * (mpcWindow + 1) + 2 * mpcWindow, 1);
    lowerBound << lowerEquality,
        lowerInequality;

    upperBound = Eigen::MatrixXd::Zero(2 * 6 * (mpcWindow + 1) + 2 * mpcWindow, 1);
    upperBound << upperEquality,
        upperInequality;
}

//更新约束向量,保证不会因为超调发散开来
void updateConstraintVectors(const Eigen::Matrix<double, 6, 1> &x0,
                             Eigen::VectorXd &lowerBound, Eigen::VectorXd &upperBound)
{
    lowerBound.block(0, 0, 6, 1) = -x0;
    upperBound.block(0, 0, 6, 1) = -x0;
}

double getErrorNorm(const Eigen::Matrix<double, 6, 1> &x,
                    const Eigen::Matrix<double, 6, 1> &xRef)
{
    // evaluate the error
    Eigen::Matrix<double, 6, 1> error = x - xRef;

    // return the norm
    return error.norm();
}

// // lcm得到数据
// class Handler
// {
// public:
//     double a[6] = [ 0, 0, 0, 0, 0, 0 ];
//     Handler() {}
//     ~Handler() {}
//     void handleMessage(const lcm::ReceiveBuffer *rbuf, const std::string &chan,
//                        const exlcm::lcmcpp *msg)
//     {
//         for (int i = 0; i < 6; i++)
//         {
//             a[i] = msg->frompy[i];
//         }
//     }
// };

int main()
{
    // set the lcm
    // lcm::LCM lcm;
    // if (!lcm.good())
    //     return 1;
    // exlcm::lcmcpp my_data;
    // set the preview window
    int mpcWindow = 20;
    //总共预测后来一秒钟以内发生的事情
    Eigen::VectorXd x_rec;
    // allocate the dynamics matrices
    Eigen::Matrix<double, 6, 6> a;
    Eigen::Matrix<double, 6, 2> b;

    // allocate the constraints vector
    Eigen::Matrix<double, 6, 1> xMax;
    Eigen::Matrix<double, 6, 1> xMin;
    Eigen::Matrix<double, 2, 1> uMax;
    Eigen::Matrix<double, 2, 1> uMin;

    // allocate the weight matrices
    Eigen::DiagonalMatrix<double, 6> Q;
    Eigen::DiagonalMatrix<double, 2> R;

    // allocate the initial and the reference state space
    Eigen::Matrix<double, 6, 1> x0;
    Eigen::Matrix<double, 6, 1> xRef;

    // allocate QP problem matrices and vectores
    Eigen::SparseMatrix<double> hessian;
    Eigen::VectorXd gradient;
    Eigen::SparseMatrix<double> linearMatrix;
    Eigen::VectorXd lowerBound;
    Eigen::VectorXd upperBound;

    // // lcm listener
    // Handler handlerObject;
    // lcm.subscribe("DATA", &Handler::handleMessage, &handlerObject);

    // set the initial and the desired states
    // 得到x值，这里是一个初始化的地方
    x0 << 0, 1, 0, 0, 0, 0;

    // 需要输入参考值的地方
    xRef << 0, 0, 0, 0, 0, 0;

    // set MPC problem quantities
    setDynamicsMatrices(a, b);
    setInequalityConstraints(xMax, xMin, uMax, uMin);
    setWeightMatrices(Q, R);

    // cast the MPC problem as QP problem
    castMPCToQPHessian(Q, R, mpcWindow, hessian);
    castMPCToQPGradient(Q, xRef, mpcWindow, gradient);
    castMPCToQPConstraintMatrix(a, b, mpcWindow, linearMatrix);
    castMPCToQPConstraintVectors(xMax, xMin, uMax, uMin, x0, mpcWindow, lowerBound, upperBound);

    // instantiate the solver
    OsqpEigen::Solver solver;

    // settings
    // solver.settings()->setVerbosity(false);
    solver.settings()->setWarmStart(true);

    // set the initial data of the QP solver
    solver.data()->setNumberOfVariables(6 * (mpcWindow + 1) + 2 * mpcWindow);
    solver.data()->setNumberOfConstraints(2 * 6 * (mpcWindow + 1) + 2 * mpcWindow);
    if (!solver.data()->setHessianMatrix(hessian))
        return 1;
    if (!solver.data()->setGradient(gradient))
        return 1;
    if (!solver.data()->setLinearConstraintsMatrix(linearMatrix))
        return 1;
    if (!solver.data()->setLowerBound(lowerBound))
        return 1;
    if (!solver.data()->setUpperBound(upperBound))
        return 1;

    // instantiate the solver
    if (!solver.initSolver())
        return 1;

    // controller input and QPSolution vector
    Eigen::Vector2d ctr;
    Eigen::VectorXd QPSolution;

    // number of iteration steps
    int numberOfSteps = 20;

    for (int i = 0; i < numberOfSteps; i++)
    {

        // solve the QP problem
        if (solver.solveProblem() != OsqpEigen::ErrorExitFlag::NoError)
            return 1;
        // get the controller input
        QPSolution = solver.getSolution();
        // @essential
        ctr = QPSolution.block(6 * (mpcWindow + 1), 0, 2, 1);
        // save data into file
        // @essential下一阶段的状态量的估计
        x0 = a * x0 + b * ctr;
        std::cout <<"第"<<i+1<<"次的X(1):"<<x0(1)<<"\t"<<"control:"<<ctr.transpose()<< std::endl;
        // update the constraint bound
        updateConstraintVectors(x0, lowerBound, upperBound);
        if (!solver.updateBounds(lowerBound, upperBound))
            return 1;
    }
    // std::cout<<"A:"<<std::endl;
    // print_matrix(a);
    // std::cout<<"B:"<<std::endl;
    // print_matrix(b);
    // lcm.publish("DATA", &my_data);
    // printf("ok");
    return 0;
}
